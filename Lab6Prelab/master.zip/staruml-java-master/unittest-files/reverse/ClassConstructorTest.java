package com.mycompany.packagetest;

public class ClassConstructorTest {

    public ClassConstructorTest() {}

}
