package com.mycompany.packagetest;

// Generic Class
public class ClassGenericTest<E, T extends java.util.Collection> {
}
