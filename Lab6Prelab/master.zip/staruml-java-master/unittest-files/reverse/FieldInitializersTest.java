package com.mycompany.packagetest;

public class FieldInitializersTest {

    int intFieldInitializer = 10;
    
    String stringFieldInitializer = "String Literal";
    
    char charFieldInitializer = 'c';
    
    boolean booleanFieldInitializer = true;
    
    Object objectFieldInitializer = null;
    
}
