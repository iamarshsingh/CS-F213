package com.mycompany.packagetest;

/**
 * JavaDoc for Enum
 */
public enum JavaDocEnumTest {

    /**
     * JavaDoc for EnumConstant1
     */
    JAVADOC_ENUM_CONSTANT1(false),
        
    /**
     * JavaDoc for EnumConstant2
     */
    JAVADOC_ENUM_CONSTANT2(true);

}
