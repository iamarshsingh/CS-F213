package com.mycompany.packagetest;

public class MethodTest {

    void methodTest() {}

}
