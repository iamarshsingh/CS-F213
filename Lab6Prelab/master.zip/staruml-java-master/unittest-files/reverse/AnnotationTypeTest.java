package com.mycompany.packagetest;

@interface AnnotationTypeTest {
    
    // Annotation Type Elements
    String annotationTypeElement();
    
    // Annotation Type Element with Default
    String annotationTypeElementWithDefault() default "N/A";
    
}
