package com.mycompany.packagetest;

public abstract class ClassAbstractTest {
}
