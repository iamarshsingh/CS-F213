/**
 * This class uses the classes in the Resources package to simulate tourists
 * coming to the city.
 * 
 * @author Ronak, Kunal, Hrishikesh, Alish
 * @version 20-November, 2018
 * 
 */
public class City {

	/**
	 * A Hotel with three star rating.
	 */
	public Hotel threeStarHotel;

	/**
	 * A Hotel with four star rating.
	 */
	public Hotel fourStarHotel;

	/**
	 * A Hotel with five star rating.
	 */
	public Hotel fiveStarHotel;

	/**
	 * A DiningHall
	 */
	public DiningHall diningHall;

	/**
	 * An array of Guests.
	 */
	public Guest[] guests;

	/**
	 * An array of Threads which are to be initialized with the guests.
	 */
	public Thread[] threads;

}
